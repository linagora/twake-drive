# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.6.1](https://github.com/cozy/cozy-libs/compare/cozy-search@2.6.0...cozy-search@2.6.1) (2026-09-23)

**Note:** Version bump only for package cozy-search

# [2.6.0](https://github.com/cozy/cozy-libs/compare/cozy-search@2.5.1...cozy-search@2.6.0) (2026-09-22)

### Features

- **cozy-search:** Use the rag-index triggers as the setup marker ([576253e](https://github.com/cozy/cozy-libs/commit/576253ee9167c7dd46ae11d369b9ca7c7ea814a4))

## [2.5.1](https://github.com/cozy/cozy-libs/compare/cozy-search@2.5.0...cozy-search@2.5.1) (2026-09-21)

**Note:** Version bump only for package cozy-search

# [2.5.0](https://github.com/cozy/cozy-libs/compare/cozy-search@2.4.0...cozy-search@2.5.0) (2026-09-18)

### Features

- **cozy-search:** Ensure only the rag-index triggers at startup ([c1ee201](https://github.com/cozy/cozy-libs/commit/c1ee201b4548ffa82f9e8ecd194ebca9ec71753f))

# [2.4.0](https://github.com/cozy/cozy-libs/compare/cozy-search@2.3.3...cozy-search@2.4.0) (2026-09-18)

### Bug Fixes

- **cozy-search:** Refetch the queries after 5 minutes ([b4b5139](https://github.com/cozy/cozy-libs/commit/b4b5139c4bf9626e13ea3664bc2eff773abd08b2))

### Features

- **cozy-search:** Provision the flagged assistants on assistant open ([817d85f](https://github.com/cozy/cozy-libs/commit/817d85f55c7113fca6eb936eab15b93f24d31cc2))
- **cozy-search:** Rename the autoprovision flag to cozy.assistant.\* ([6bc3c2e](https://github.com/cozy/cozy-libs/commit/6bc3c2e37458bf424886e493fab25175eeb7e8e5))

## [2.3.3](https://github.com/cozy/cozy-libs/compare/cozy-search@2.3.2...cozy-search@2.3.3) (2026-09-17)

### Bug Fixes

- **cozy-search:** Query the assistant without include in provisioning ([83dcc31](https://github.com/cozy/cozy-libs/commit/83dcc31e4839fd5617bacf12c85ce34afe5d3f8d))

## [2.3.2](https://github.com/cozy/cozy-libs/compare/cozy-search@2.3.1...cozy-search@2.3.2) (2026-09-16)

**Note:** Version bump only for package cozy-search

## [2.3.1](https://github.com/cozy/cozy-libs/compare/cozy-search@2.3.0...cozy-search@2.3.1) (2026-09-16)

**Note:** Version bump only for package cozy-search

# [2.3.0](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.30...cozy-search@2.3.0) (2026-09-15)

### Features

- **cozy-search:** Ensure root folder in every knowledge base ([03c1165](https://github.com/cozy/cozy-libs/commit/03c11650779fff77086c575e5fabb1389cb0dc21))
- **cozy-search:** Provision flag-defined assistants ([4cda68d](https://github.com/cozy/cozy-libs/commit/4cda68d4fc2b596f2a11485126365f5fffb78e55))
- **cozy-search:** Set up instance-wide rag-index triggers at startup ([7390c8c](https://github.com/cozy/cozy-libs/commit/7390c8c29cd88591b99d59539a4626ad87f40304))
- **cozy-search:** Start conversations on the flagged default assistant ([225f3df](https://github.com/cozy/cozy-libs/commit/225f3df54d664cc928e59202b6907198cf50a493))

## [2.2.30](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.29...cozy-search@2.2.30) (2026-09-15)

**Note:** Version bump only for package cozy-search

## [2.2.29](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.28...cozy-search@2.2.29) (2026-09-14)

**Note:** Version bump only for package cozy-search

## [2.2.28](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.27...cozy-search@2.2.28) (2026-09-10)

**Note:** Version bump only for package cozy-search

## [2.2.27](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.26...cozy-search@2.2.27) (2026-09-08)

### Bug Fixes

- **cozy-search:** Display each RAG source only once ([2918db9](https://github.com/cozy/cozy-libs/commit/2918db9cb3e40730f845edc361486b1979aa3852))

## [2.2.26](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.25...cozy-search@2.2.26) (2026-09-07)

**Note:** Version bump only for package cozy-search

## [2.2.25](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.24...cozy-search@2.2.25) (2026-09-03)

### Bug Fixes

- **cozy-search:** Avoid rendering undefined in email sources ([8e738cc](https://github.com/cozy/cozy-libs/commit/8e738cca86b04528f33d6316d98b7f2a99675166))

## [2.2.24](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.23...cozy-search@2.2.24) (2026-09-02)

**Note:** Version bump only for package cozy-search

## [2.2.23](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.22...cozy-search@2.2.23) (2026-09-01)

**Note:** Version bump only for package cozy-search

## [2.2.22](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.21...cozy-search@2.2.22) (2026-08-31)

**Note:** Version bump only for package cozy-search

## [2.2.21](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.20...cozy-search@2.2.21) (2026-08-31)

**Note:** Version bump only for package cozy-search

## [2.2.20](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.19...cozy-search@2.2.20) (2026-08-28)

### Bug Fixes

- **cozy-search:** Name the provider account after the provider ([60f1bfc](https://github.com/cozy/cozy-libs/commit/60f1bfc5bf8edd07147c7df0e446dd7565ab9f08))
- **cozy-search:** Read the assistant model from the account data ([d3050aa](https://github.com/cozy/cozy-libs/commit/d3050aad1c5126eb992b0727ef21aff70d1013e2))

## [2.2.19](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.18...cozy-search@2.2.19) (2026-08-27)

### Bug Fixes

- **cozy-search:** Add fallback message for empty assistant replies ([2428017](https://github.com/cozy/cozy-libs/commit/242801715e53daa79d7a0f76dfbef6d5f7ba36ac))

## [2.2.18](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.17...cozy-search@2.2.18) (2026-08-26)

**Note:** Version bump only for package cozy-search

## [2.2.17](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.16...cozy-search@2.2.17) (2026-08-25)

**Note:** Version bump only for package cozy-search

## [2.2.16](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.15...cozy-search@2.2.16) (2026-08-25)

**Note:** Version bump only for package cozy-search

## [2.2.15](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.14...cozy-search@2.2.15) (2026-08-25)

**Note:** Version bump only for package cozy-search

## [2.2.14](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.13...cozy-search@2.2.14) (2026-08-24)

**Note:** Version bump only for package cozy-search

## [2.2.13](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.12...cozy-search@2.2.13) (2026-07-30)

**Note:** Version bump only for package cozy-search

## [2.2.12](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.11...cozy-search@2.2.12) (2026-07-30)

**Note:** Version bump only for package cozy-search

## [2.2.11](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.10...cozy-search@2.2.11) (2026-07-30)

**Note:** Version bump only for package cozy-search

## [2.2.10](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.9...cozy-search@2.2.10) (2026-07-29)

### Bug Fixes

- **assistant:** Blur the websearch chip after a pointer click ([c755a9b](https://github.com/cozy/cozy-libs/commit/c755a9be34ed9aaff7acaa3820d1ba4f15482008))
- **assistant:** Rename the default assistant to "AI Agent" ([d4a9d3d](https://github.com/cozy/cozy-libs/commit/d4a9d3d5bfba56303ba91cf8656411ce6b474355))
- **assistant:** Show a dropdown chevron on the assistant chip ([93640c8](https://github.com/cozy/cozy-libs/commit/93640c8162474047a101fe2e9002ba69ec6aa463))

## [2.2.9](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.8...cozy-search@2.2.9) (2026-07-29)

**Note:** Version bump only for package cozy-search

## [2.2.8](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.7...cozy-search@2.2.8) (2026-07-29)

**Note:** Version bump only for package cozy-search

## [2.2.7](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.6...cozy-search@2.2.7) (2026-07-29)

**Note:** Version bump only for package cozy-search

## [2.2.6](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.5...cozy-search@2.2.6) (2026-07-28)

**Note:** Version bump only for package cozy-search

## [2.2.5](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.4...cozy-search@2.2.5) (2026-07-28)

**Note:** Version bump only for package cozy-search

## [2.2.4](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.3...cozy-search@2.2.4) (2026-07-27)

**Note:** Version bump only for package cozy-search

## [2.2.3](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.2...cozy-search@2.2.3) (2026-07-23)

**Note:** Version bump only for package cozy-search

## [2.2.2](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.1...cozy-search@2.2.2) (2026-07-23)

### Bug Fixes

- AI providers ([4d80f13](https://github.com/cozy/cozy-libs/commit/4d80f1314afdd002d196b93542778a8ea008d903))

## [2.2.1](https://github.com/cozy/cozy-libs/compare/cozy-search@2.2.0...cozy-search@2.2.1) (2026-07-22)

**Note:** Version bump only for package cozy-search

# [2.2.0](https://github.com/cozy/cozy-libs/compare/cozy-search@2.1.1...cozy-search@2.2.0) (2026-07-22)

### Bug Fixes

- **cozy-search:** Don't send default assistant sentinel to the stack ([6385d0e](https://github.com/cozy/cozy-libs/commit/6385d0e1b88c6689e5865edca43241f1b0705242))

### Features

- **cozy-search:** Add agent description field in creation wizard ([71cda0d](https://github.com/cozy/cozy-libs/commit/71cda0de13b88c3d2a65d2bc606c7fcaa691a6c3))

## [2.1.1](https://github.com/cozy/cozy-libs/compare/cozy-search@2.1.0...cozy-search@2.1.1) (2026-07-22)

**Note:** Version bump only for package cozy-search

# [2.1.0](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.11...cozy-search@2.1.0) (2026-07-22)

### Features

- **cozy-search:** Add assistant knowledge base with Drive folder source ([14199bd](https://github.com/cozy/cozy-libs/commit/14199bdd8861b0ca6b2fe00647063863902acb46))
- **cozy-search:** Select emails as knowledge base source ([6d6c882](https://github.com/cozy/cozy-libs/commit/6d6c882c9416069d3ea73965073d7456a80f8386))
- **cozy-search:** Wire composer source chips to the knowledge base ([35ef740](https://github.com/cozy/cozy-libs/commit/35ef7400058b054b57097150b2c796403ac213df))

## [2.0.11](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.10...cozy-search@2.0.11) (2026-07-21)

**Note:** Version bump only for package cozy-search

## [2.0.10](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.9...cozy-search@2.0.10) (2026-07-21)

**Note:** Version bump only for package cozy-search

## [2.0.9](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.8...cozy-search@2.0.9) (2026-07-21)

**Note:** Version bump only for package cozy-search

## [2.0.8](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.7...cozy-search@2.0.8) (2026-07-17)

**Note:** Version bump only for package cozy-search

## [2.0.7](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.6...cozy-search@2.0.7) (2026-07-16)

**Note:** Version bump only for package cozy-search

## [2.0.6](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.5...cozy-search@2.0.6) (2026-07-16)

**Note:** Version bump only for package cozy-search

## [2.0.5](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.4...cozy-search@2.0.5) (2026-07-09)

**Note:** Version bump only for package cozy-search

## [2.0.4](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.3...cozy-search@2.0.4) (2026-07-09)

**Note:** Version bump only for package cozy-search

## [2.0.3](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.2...cozy-search@2.0.3) (2026-07-08)

**Note:** Version bump only for package cozy-search

## [2.0.2](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.1...cozy-search@2.0.2) (2026-07-06)

### Bug Fixes

- **cozy-search:** Fix custom provider icon and select new assistant ([dba1652](https://github.com/cozy/cozy-libs/commit/dba16526dfc20a5aeec805f1e9c082521322f094))

## [2.0.1](https://github.com/cozy/cozy-libs/compare/cozy-search@2.0.0...cozy-search@2.0.1) (2026-06-26)

### Bug Fixes

- **cozy-search:** Align sidebar items and icons to 16px gutter ([3d45f74](https://github.com/cozy/cozy-libs/commit/3d45f74b34706e03755c541ef79d43895e183780))

# [2.0.0](https://github.com/cozy/cozy-libs/compare/cozy-search@1.1.0...cozy-search@2.0.0) (2026-06-25)

### Features

- Ugrade twake-icons in libs and remove test mock ([46178bc](https://github.com/cozy/cozy-libs/commit/46178bcfff73fb8486b6a5209a14e306b497371b))

### BREAKING CHANGES

- You must have `@linagora/twake-icons >=2.6.6`

# [1.1.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.30.1...cozy-search@1.1.0) (2026-06-24)

### Features

- **cozy-search:** Bump to 1.0.0 ([27c5cb7](https://github.com/cozy/cozy-libs/commit/27c5cb7618e25e6a3d83877317cc1bb922769821))
- **cozy-search:** Bump to 1.0.0 ([9e84e2a](https://github.com/cozy/cozy-libs/commit/9e84e2a59a7c9962f4ce7e2b9488a1478e1eff2b))

## [0.30.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.30.0...cozy-search@0.30.1) (2026-06-24)

**Note:** Version bump only for package cozy-search

# [0.30.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.29.2...cozy-search@0.30.0) (2026-06-24)

### Features

- **cozy-search:** Add twake-icons ([8cd4f71](https://github.com/cozy/cozy-libs/commit/8cd4f7186de04b2f359605029d445c85ff5b11b8))

### BREAKING CHANGES

- **cozy-search:** You must add `@linagora/twake-icons >= 2.6.2`

## [0.29.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.29.1...cozy-search@0.29.2) (2026-06-11)

**Note:** Version bump only for package cozy-search

## [0.29.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.29.0...cozy-search@0.29.1) (2026-06-04)

### Bug Fixes

- **cozy-search:** Remove blue tint from sidebar collapse icon ([82b6605](https://github.com/cozy/cozy-libs/commit/82b660556201e2e329176a76d2de954bb586f13e))

# [0.29.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.28.0...cozy-search@0.29.0) (2026-06-02)

### Bug Fixes

- **cozy-search:** Keep assistant menu width stable on hover ([b059401](https://github.com/cozy/cozy-libs/commit/b0594017d0624954d7a5557709fcfc3291499f15))

### Features

- **cozy-search:** Block o1 models on OpenAI provider ([bf92e4a](https://github.com/cozy/cozy-libs/commit/bf92e4ac75f5a9fe02c54fd9eca26ec4774b4f9e))
- **cozy-search:** Hint stored token with bullets in edit form ([bf30f87](https://github.com/cozy/cozy-libs/commit/bf30f870b55e864e007916f20f75415546f85f3c))
- **cozy-search:** Select edited assistant in the chat ([70feae3](https://github.com/cozy/cozy-libs/commit/70feae31ee6db9def2db563f7fef7cffc1ca52cb))
- **cozy-search:** Use colored AI icon as assistant fallback avatar ([db3bb42](https://github.com/cozy/cozy-libs/commit/db3bb42f82723b695594ed061cf725f0a13c7af6))
- Upgrade cozy-client to get assistant fix ([7ba2316](https://github.com/cozy/cozy-libs/commit/7ba231606e1ecc3ff33dec90164dd054299321d6))

# [0.28.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.27.0...cozy-search@0.28.0) (2026-06-02)

### Bug Fixes

- **cozy-search:** Strip [Sources: N] citation markers from preview ([7155564](https://github.com/cozy/cozy-libs/commit/7155564201742db38021b00765d923937114d92a))

### Features

- **cozy-search:** Refine source selection chips row with web search ([cec649f](https://github.com/cozy/cozy-libs/commit/cec649f90144fe4b0b06ea6ee159e4366140afc5))
- **cozy-search:** Refresh inbox emails and truncate long previews ([b648f17](https://github.com/cozy/cozy-libs/commit/b648f17dcb21e50067d5df2702e273ea4f378134))
- **cozy-search:** Restructure Drive sources as collapsible folders ([45dcd52](https://github.com/cozy/cozy-libs/commit/45dcd52106ae472ce169d104b751d8aea48d00d9))

# [0.27.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.26.3...cozy-search@0.27.0) (2026-05-26)

### Bug Fixes

- **cozy-search:** Delete assistants through the cozy-client store ([96cb9a4](https://github.com/cozy/cozy-libs/commit/96cb9a4e7e5ad45fb97efc236e00b070a2ab448b))
- **cozy-search:** Strip inline [Source N] citation markers ([a8e1cf6](https://github.com/cozy/cozy-libs/commit/a8e1cf69254e5d79d936278b677e2ed7c7c7a53e))

### Features

- **cozy-search:** Group conversation search results by day ([cba9cc5](https://github.com/cozy/cozy-libs/commit/cba9cc50e3df69f13b92c8a0205d8e4d1f0212ce))
- **cozy-search:** Speed up conversation list switching ([bb73490](https://github.com/cozy/cozy-libs/commit/bb7349074eb764828bbf92bd232c65908a463f47))

## [0.26.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.26.2...cozy-search@0.26.3) (2026-05-18)

**Note:** Version bump only for package cozy-search

## [0.26.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.26.1...cozy-search@0.26.2) (2026-05-07)

**Note:** Version bump only for package cozy-search

## [0.26.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.26.0...cozy-search@0.26.1) (2026-04-22)

**Note:** Version bump only for package cozy-search

# [0.26.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.25.3...cozy-search@0.26.0) (2026-04-20)

### Features

- Add websearch toggle to AI chat input ([a4c6bc6](https://github.com/cozy/cozy-libs/commit/a4c6bc6a16193dd78463e79ba9f22df57e0f84b6))
- Display websearch URL sources in assistant chat ([c27bf81](https://github.com/cozy/cozy-libs/commit/c27bf8159652259b617f78aa8ae6bcf1760deb86))

## [0.25.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.25.2...cozy-search@0.25.3) (2026-04-07)

**Note:** Version bump only for package cozy-search

## [0.25.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.25.1...cozy-search@0.25.2) (2026-04-02)

**Note:** Version bump only for package cozy-search

## [0.25.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.25.0...cozy-search@0.25.1) (2026-04-02)

**Note:** Version bump only for package cozy-search

# [0.25.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.24.1...cozy-search@0.25.0) (2026-03-25)

### Features

- Expose AiText in cozy-search ([5ed860f](https://github.com/cozy/cozy-libs/commit/5ed860fe6978c854f28b14cb6638425c2b2ef60a))

## [0.24.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.24.0...cozy-search@0.24.1) (2026-03-24)

### Bug Fixes

- Handle root-level assistant route navigation ([a82a9e6](https://github.com/cozy/cozy-libs/commit/a82a9e66c38d399f63128b42c571c8da9fee955c))

# [0.24.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.23.4...cozy-search@0.24.0) (2026-03-24)

### Features

- Upgrade cozy-ui and cozy-ui-plus in cozy-search and cozy-sharing ([f5fd252](https://github.com/cozy/cozy-libs/commit/f5fd2520150e276c8b55feeb1b994ba33d0a114b))

### BREAKING CHANGES

- You must have `cozy-ui >= 138.1.0 and cozy-ui-plus >= 6.0.0`

## [0.23.4](https://github.com/cozy/cozy-libs/compare/cozy-search@0.23.3...cozy-search@0.23.4) (2026-03-24)

**Note:** Version bump only for package cozy-search

## [0.23.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.23.2...cozy-search@0.23.3) (2026-03-24)

### Bug Fixes

- Handle errors when LLM cannot respond ([d659673](https://github.com/cozy/cozy-libs/commit/d65967396109f4947d93e3deb00215acdc07cadd))
- Use metadata for error detection, hide raw error ([6b0bfcf](https://github.com/cozy/cozy-libs/commit/6b0bfcfb5dca8b12a92d5ceafe84d8df9ab7c636))

## [0.23.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.23.1...cozy-search@0.23.2) (2026-03-23)

### Bug Fixes

- Sources handling in realtime ([3dd5b5d](https://github.com/cozy/cozy-libs/commit/3dd5b5d167b8e5595343c21b6b2674cababdfb0a))

## [0.23.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.23.0...cozy-search@0.23.1) (2026-03-23)

**Note:** Version bump only for package cozy-search

# [0.23.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.22.0...cozy-search@0.23.0) (2026-03-23)

### Bug Fixes

- Icon color was not correct for Custom provider ([3d34a0a](https://github.com/cozy/cozy-libs/commit/3d34a0a693c6b5f61737785e8c9906a05b2abb8a))

### Features

- Use Twake icon for default AI ([f3ba096](https://github.com/cozy/cozy-libs/commit/f3ba09663f29ddacd17c576de2168af654f96fc7))

# [0.22.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.21.1...cozy-search@0.22.0) (2026-03-20)

### Bug Fixes

- Override color of assistant icon in assistant selector :bug: ([8a430ee](https://github.com/cozy/cozy-libs/commit/8a430eee06b30a1f064da900b1c939ecc34f5827))

### chore

- Upgrade cozy-ui to 137.0.1 :arrow_up: ([0118431](https://github.com/cozy/cozy-libs/commit/0118431b7eae9fc5554a0faa9790a0e7b1bf470a))

### BREAKING CHANGES

- You need to add cozy-ui >= 137.0.1 as dep in your app :heavy_plus_sign:

## [0.21.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.21.0...cozy-search@0.21.1) (2026-03-20)

### Bug Fixes

- Use \_id for assistant selection and actions :bug: ([fc2de5b](https://github.com/cozy/cozy-libs/commit/fc2de5bc8b86d5380765f957dd1e02fcb24e1780))

# [0.21.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.20.0...cozy-search@0.21.0) (2026-03-20)

### Bug Fixes

- **cozy-search:** Display sources in assistant-ui messages :bug: ([60a81f1](https://github.com/cozy/cozy-libs/commit/60a81f1859ccf95b7963f9ee69e381b877c441d3))

### Features

- Add realtime updates for conversation list :sparkles: ([37ac570](https://github.com/cozy/cozy-libs/commit/37ac5700422d40a122350cf77cdbc1fbac249968))
- Add rename and delete conversation actions :sparkles: ([383e179](https://github.com/cozy/cozy-libs/commit/383e179d2d94056c485a5d53588300e4fd2a4bae))

# [0.20.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.19.2...cozy-search@0.20.0) (2026-03-18)

### Bug Fixes

- Init default provider data for openrag assistant :bug: ([4fee703](https://github.com/cozy/cozy-libs/commit/4fee7034c4bb2e0431f9ba1d57db0e08197028f6))
- Remove API key step when creating openrag assistant :bug: ([b2a0dbb](https://github.com/cozy/cozy-libs/commit/b2a0dbb2eb32eee3e984f672dc3666c4ae44a9c6))

### Features

- Change flow select provider and model :sparkles: ([3ef24b0](https://github.com/cozy/cozy-libs/commit/3ef24b0e3ee45eeb27e29d6f744b9ba2188776fa))
- Change wording of openrag :speech_balloon: ([a87e200](https://github.com/cozy/cozy-libs/commit/a87e200c967acec5fdda02f838a228cbf23a62be))
- Upgrade cozy-client for latest assistant improvements ([c91984e](https://github.com/cozy/cozy-libs/commit/c91984e1b4859a13a78ae74b2348ea2f9c1b9ae1))

## [0.19.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.19.1...cozy-search@0.19.2) (2026-03-18)

### Bug Fixes

- AI messages displayed in wrong order ([9665dc3](https://github.com/cozy/cozy-libs/commit/9665dc3c198f1cfda447bf99d49234ca34a13c87))

## [0.19.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.19.0...cozy-search@0.19.1) (2026-03-17)

**Note:** Version bump only for package cozy-search

# [0.19.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.18.2...cozy-search@0.19.0) (2026-03-17)

### Features

- Upgrade Jest to 28 ([b92c56c](https://github.com/cozy/cozy-libs/commit/b92c56ce2fdd65b3dd8e9c5170dc5eb86cc369a7))

## [0.18.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.18.1...cozy-search@0.18.2) (2026-03-16)

**Note:** Version bump only for package cozy-search

## [0.18.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.18.0...cozy-search@0.18.1) (2026-03-16)

**Note:** Version bump only for package cozy-search

# [0.18.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.17.3...cozy-search@0.18.0) (2026-03-12)

### Bug Fixes

- Adjust UI of assistant :bug: ([6c53497](https://github.com/cozy/cozy-libs/commit/6c534970b0570bd0363234783967689161b8fee9))
- Apply pagination to fetch conversations :bug: ([87701c7](https://github.com/cozy/cozy-libs/commit/87701c78d89f9949ec7279237e6ed315c880d26b))
- Avoid cancelled message ids data set from growing unbounded :bug: ([4dc33fb](https://github.com/cozy/cozy-libs/commit/4dc33fbdcc1399971822345f61a84f116bfc57a3))
- Hide running status when assistant generate answer :bug: ([eab7c37](https://github.com/cozy/cozy-libs/commit/eab7c37445f80ecb73413679503064498de521d2))
- Make mobile UI friendly :bug: ([7b21e55](https://github.com/cozy/cozy-libs/commit/7b21e557e06890ef2a7158808fcce33500b402eb))

### Features

- Display selected assistant of conversation :sparkles: ([67a9f2a](https://github.com/cozy/cozy-libs/commit/67a9f2ad9fbefc18635516ef5f920a8dc96c5477))
- Implement unit test :white_check_mark: ([42e592e](https://github.com/cozy/cozy-libs/commit/42e592e3a8d94b64c4b1be9109396a7b55021f1b))

## [0.17.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.17.2...cozy-search@0.17.3) (2026-03-09)

**Note:** Version bump only for package cozy-search

## [0.17.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.17.1...cozy-search@0.17.2) (2026-03-09)

**Note:** Version bump only for package cozy-search

## [0.17.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.17.0...cozy-search@0.17.1) (2026-03-05)

**Note:** Version bump only for package cozy-search

# [0.17.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.6...cozy-search@0.17.0) (2026-03-02)

### Features

- Add sidebar and search section :sparkles: ([17e3ee0](https://github.com/cozy/cozy-libs/commit/17e3ee0a7eae3d5544314c0fad992d3b3f4e33ae))
- Display top bar in assistant page :sparkles: ([7ded482](https://github.com/cozy/cozy-libs/commit/7ded482744d23f3acc7dc12b0c148d6c172ab23f))
- Implement source knowledge :sparkles: ([592dc39](https://github.com/cozy/cozy-libs/commit/592dc3985d1ded5e190f3dae9720253f74754413))
- Migrate assistant-ui :sparkles: ([7457d72](https://github.com/cozy/cozy-libs/commit/7457d7271e737033a31c31ff4ec8f9b8e630fb09))

### BREAKING CHANGES

- You need to upgrade react >= 18.0.0 and react-dom >= 18.0.0

## [0.16.6](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.5...cozy-search@0.16.6) (2026-02-25)

**Note:** Version bump only for package cozy-search

## [0.16.5](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.4...cozy-search@0.16.5) (2026-02-23)

**Note:** Version bump only for package cozy-search

## [0.16.4](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.3...cozy-search@0.16.4) (2026-02-20)

### Bug Fixes

- Adding FIXME comment ([b2ba5ff](https://github.com/cozy/cozy-libs/commit/b2ba5ff5787f72e5283b75cbd1eb73e8fee976f1))
- **email:** Fixing email link ([04b643b](https://github.com/cozy/cozy-libs/commit/04b643bb4e2dffec133115a709028a50cc7f0649))

## [0.16.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.2...cozy-search@0.16.3) (2026-02-19)

**Note:** Version bump only for package cozy-search

## [0.16.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.1...cozy-search@0.16.2) (2026-02-03)

**Note:** Version bump only for package cozy-search

## [0.16.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.16.0...cozy-search@0.16.1) (2026-02-02)

**Note:** Version bump only for package cozy-search

# [0.16.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.15.1...cozy-search@0.16.0) (2026-02-02)

### Features

- Implement create, edit, delete assistant :sparkles: ([e816394](https://github.com/cozy/cozy-libs/commit/e816394401b68fd3c68c8de1251763fb3637a194))

### BREAKING CHANGES

- You need to upgrade cozy-client >= 60.21.0 :heavy_plus_sign:

## [0.15.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.15.0...cozy-search@0.15.1) (2026-01-29)

**Note:** Version bump only for package cozy-search

# [0.15.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.14.4...cozy-search@0.15.0) (2026-01-22)

### Bug Fixes

- **email:** Enhancing style ([bb28d8f](https://github.com/cozy/cozy-libs/commit/bb28d8f0d569eab15bd52c89e5f450804cfdf5c3))
- **email:** Renaming emailSources to email to have consistent naming ([9c0a566](https://github.com/cozy/cozy-libs/commit/9c0a56617d3ce7a0a46c87b865755fd34975c2c3))

### Features

- Add email source ([f10da09](https://github.com/cozy/cozy-libs/commit/f10da098528ef42cad4b9df8f682b989f4b5b78b))
- **aiAssistant:** Finxing lint ([b4b2f56](https://github.com/cozy/cozy-libs/commit/b4b2f56aefdd02cae5743bba87765823ec13b5d8))
- **email:** Adding noopener noreferrer to email link ([dbc80d6](https://github.com/cozy/cozy-libs/commit/dbc80d66f2262e47045c86528ce03d4ad758eda6))
- **email:** Enhancing display + handling redirect link ([72cdcf2](https://github.com/cozy/cozy-libs/commit/72cdcf28e431524848c849a27351b179c592e3bc))
- **email:** Fix metadata and empty file handling ([9196d49](https://github.com/cozy/cozy-libs/commit/9196d495fc170e9147497d275d545e1e455fefde))

## [0.14.4](https://github.com/cozy/cozy-libs/compare/cozy-search@0.14.3...cozy-search@0.14.4) (2026-01-15)

**Note:** Version bump only for package cozy-search

## [0.14.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.14.2...cozy-search@0.14.3) (2026-01-14)

**Note:** Version bump only for package cozy-search

## [0.14.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.14.1...cozy-search@0.14.2) (2026-01-14)

**Note:** Version bump only for package cozy-search

## [0.14.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.14.0...cozy-search@0.14.1) (2025-12-10)

### Bug Fixes

- Resolve import problem of useExtendedI18n in twake-i18n :bug: ([b997dbf](https://github.com/cozy/cozy-libs/commit/b997dbfddc136ead43d32faba997ee7fb08d5094))

# [0.14.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.8...cozy-search@0.14.0) (2025-12-04)

### Features

- Add twake-i18n in packages ([f8689a9](https://github.com/cozy/cozy-libs/commit/f8689a9a58dc6384ccf494a19fd1afb595da39f0))

### BREAKING CHANGES

- You must have `twake-i18n >= 0.3.0` and `cozy-ui >= 135.0.0`

## [0.13.8](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.7...cozy-search@0.13.8) (2025-12-04)

**Note:** Version bump only for package cozy-search

## [0.13.7](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.6...cozy-search@0.13.7) (2025-12-04)

**Note:** Version bump only for package cozy-search

## [0.13.6](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.5...cozy-search@0.13.6) (2025-12-04)

**Note:** Version bump only for package cozy-search

## [0.13.5](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.4...cozy-search@0.13.5) (2025-11-13)

**Note:** Version bump only for package cozy-search

## [0.13.4](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.3...cozy-search@0.13.4) (2025-11-13)

**Note:** Version bump only for package cozy-search

## [0.13.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.2...cozy-search@0.13.3) (2025-11-05)

**Note:** Version bump only for package cozy-search

## [0.13.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.1...cozy-search@0.13.2) (2025-11-05)

**Note:** Version bump only for package cozy-search

## [0.13.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.13.0...cozy-search@0.13.1) (2025-11-05)

**Note:** Version bump only for package cozy-search

# [0.13.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.12.1...cozy-search@0.13.0) (2025-10-30)

### Features

- Forgot to create BC when adding `cozy-ui-plus` in some packages ([3a14a14](https://github.com/cozy/cozy-libs/commit/3a14a14122618ad1ec3a1ba5d6b217a9c827c925))

### BREAKING CHANGES

- You must have `cozy-ui-plus >= 1.2.0`

## [0.12.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.12.0...cozy-search@0.12.1) (2025-10-30)

**Note:** Version bump only for package cozy-search

# [0.12.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.11.2...cozy-search@0.12.0) (2025-10-30)

### Features

- Add `cozy-ui-plus` to replace `cozy-ui` components c90db9 ([789c60f](https://github.com/cozy/cozy-libs/commit/789c60f260cc090b31aa0bf13770d18f0813f670))

## [0.11.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.11.1...cozy-search@0.11.2) (2025-10-30)

**Note:** Version bump only for package cozy-search

## [0.11.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.11.0...cozy-search@0.11.1) (2025-09-25)

**Note:** Version bump only for package cozy-search

# [0.11.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.10.0...cozy-search@0.11.0) (2025-09-24)

### Features

- **cozy-search:** Add ru and vi locales ([aa77667](https://github.com/cozy/cozy-libs/commit/aa7766717698176b7fbb16802230d02fe084edc3))

# [0.10.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.9.1...cozy-search@0.10.0) (2025-09-19)

### Features

- Enable search options at search time ([671e4f5](https://github.com/cozy/cozy-libs/commit/671e4f56ead88a18bb0987b9a5e226914687a383))

## [0.9.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.9.0...cozy-search@0.9.1) (2025-09-18)

**Note:** Version bump only for package cozy-search

# [0.9.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.8.5...cozy-search@0.9.0) (2025-09-09)

### Features

- Dedup classnames package ([6ac12d3](https://github.com/cozy/cozy-libs/commit/6ac12d3be9ec9ec1b8ceb90b2b6826ef650d48f9))
- Dedup lodash package ([93ebfd0](https://github.com/cozy/cozy-libs/commit/93ebfd010456639ec94552fc5bb7e6790811cf56))

## [0.8.5](https://github.com/cozy/cozy-libs/compare/cozy-search@0.8.4...cozy-search@0.8.5) (2025-09-05)

**Note:** Version bump only for package cozy-search

## [0.8.4](https://github.com/cozy/cozy-libs/compare/cozy-search@0.8.3...cozy-search@0.8.4) (2025-08-21)

**Note:** Version bump only for package cozy-search

## [0.8.3](https://github.com/cozy/cozy-libs/compare/cozy-search@0.8.2...cozy-search@0.8.3) (2025-06-26)

### Bug Fixes

- Avoid crashing on non-string element ([33a7bbf](https://github.com/cozy/cozy-libs/commit/33a7bbff87cb5fafd57e69339aa484f4ddb990f3))
- Properly handle LLM Ref ([3e156a0](https://github.com/cozy/cozy-libs/commit/3e156a0b5aee0c1910ae4366684334ed056d0d5e))

## [0.8.2](https://github.com/cozy/cozy-libs/compare/cozy-search@0.8.1...cozy-search@0.8.2) (2025-06-24)

### Bug Fixes

- Remove LLM sources tags ([95b9e49](https://github.com/cozy/cozy-libs/commit/95b9e497c47d951be686ff7e2895533d474861e3))

## [0.8.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.8.0...cozy-search@0.8.1) (2025-06-13)

### Bug Fixes

- Upgrade cozy-client peerDep to use search ([19521e8](https://github.com/cozy/cozy-libs/commit/19521e88f31c37f7776c0d3279d227c2d99a3271))

# [0.8.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.7.0...cozy-search@0.8.0) (2025-06-13)

### Features

- Correctly handle icon ([eadde85](https://github.com/cozy/cozy-libs/commit/eadde85752c6ede6217bc4fa435cdcee736cccfd))
- Redirect Docs sources to correct app ([be65ef6](https://github.com/cozy/cozy-libs/commit/be65ef68525381577d278343fd216da0f6f6416c))

# [0.7.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.6.1...cozy-search@0.7.0) (2025-05-28)

### Bug Fixes

- Close search results when navigating in same tab ([e03804f](https://github.com/cozy/cozy-libs/commit/e03804fcbd4c80c1a52be511ad2723b4a2a6eac2))
- Do not show loader at AI chat open ([8a73606](https://github.com/cozy/cozy-libs/commit/8a736065a4200e5a4831a01998529fb76b8c6107))
- Press Enter when element is first in result do nothing ([12f3891](https://github.com/cozy/cozy-libs/commit/12f3891971a85e827dca7437ba9a3d39444c2c61))
- SearchDialog and AssistantDialog goes to previous page when ([5545b1e](https://github.com/cozy/cozy-libs/commit/5545b1e4210db7878532a28ee7c0fe3c59659315))

### Features

- Expose componentsProps.SearchBar in mobile search ([d4e4cb3](https://github.com/cozy/cozy-libs/commit/d4e4cb317e3535df6fc00d5b5f816c7e8e0a68c5))
- Navigate in same tab if search result is from same app ([fa28af1](https://github.com/cozy/cozy-libs/commit/fa28af13cee580874a1a4dd9011615128e602c0a))
- Remove last assistant code in search ([a7f21ab](https://github.com/cozy/cozy-libs/commit/a7f21abe0e91dddb205d05a86a0bebc8d8c6619f))
- Scroll to element when navigating with keyboard ([68e15a3](https://github.com/cozy/cozy-libs/commit/68e15a3ac45d8e0af5c8f4238cea4b017921ea58))
- Use a tag instead of onClick in search result ([6160583](https://github.com/cozy/cozy-libs/commit/6160583e1303b64cbc89cf0c42cd545a651c21c6))

## [0.6.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.6.0...cozy-search@0.6.1) (2025-05-16)

### Bug Fixes

- Do not crash on missing myself contact ([c9acd32](https://github.com/cozy/cozy-libs/commit/c9acd325d871e6c3df9d2bf82209d09bc059551b))

# [0.6.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.5.1...cozy-search@0.6.0) (2025-05-14)

### Bug Fixes

- Display no result even if assistant disabled ([59e8a55](https://github.com/cozy/cozy-libs/commit/59e8a55503ab74fbc448f231ec45eac008eff941))

### Features

- Remove isTwakeTheme from cozy-search ([be40991](https://github.com/cozy/cozy-libs/commit/be409919551c3e78b15bfbc50c4994fa56d2922c))

## [0.5.1](https://github.com/cozy/cozy-libs/compare/cozy-search@0.5.0...cozy-search@0.5.1) (2025-04-16)

### Bug Fixes

- Set correct avatar size ([8ec8788](https://github.com/cozy/cozy-libs/commit/8ec87883250eeadf72b4468b72d7e93354117aa6))

# [0.5.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.4.0...cozy-search@0.5.0) (2025-04-16)

### Bug Fixes

- ConversationBar end icons were not round ([2a0d33a](https://github.com/cozy/cozy-libs/commit/2a0d33a8c61ac2146cf4dd0268b3bca89b522c4b))
- Use correct size for Avatar ([8745f51](https://github.com/cozy/cozy-libs/commit/8745f5118d0e6a7583bc02658160744984be93c7))

### Features

- Add an AssistantLink ([cf3e0ae](https://github.com/cozy/cozy-libs/commit/cf3e0ae3e1483fba93683f797187af1aca75528e))

# [0.4.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.3.0...cozy-search@0.4.0) (2025-04-10)

### Features

- **Search:** Add AI assistant in Twake theme ([ba8d70d](https://github.com/cozy/cozy-libs/commit/ba8d70d0e56c502d7e1cba9546094aeecc02d54d))
- **Search:** Allow to disable hover in SearchBarDesktop ([3396e17](https://github.com/cozy/cozy-libs/commit/3396e1787de2b4d2ff37dce5f3f84713c8687247))
- **Search:** Set same color for icon as placeholder in Twake theme ([3c9e9c4](https://github.com/cozy/cozy-libs/commit/3c9e9c4068d3c53651a19e16c83362fe261a3781))
- **Search:** Update mobile search bar in Twake theme ([aee189b](https://github.com/cozy/cozy-libs/commit/aee189bf4e6eb0ce6c9e63585b55c04991438e8a))
- Use primary color for assistant icon ([0514a2f](https://github.com/cozy/cozy-libs/commit/0514a2f757b8f111b65223df6c554a5183ea0e0d))

# [0.3.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.2.0...cozy-search@0.3.0) (2025-04-04)

### Features

- Allow to pass className in componentsProps.SearchBarDesktop ([52c41f1](https://github.com/cozy/cozy-libs/commit/52c41f1525e3ce89873d67c99f63f3721d407386))
- Update cozy-ui in cozy-search ([88d04a6](https://github.com/cozy/cozy-libs/commit/88d04a676ab76132a388c8a4e424bb92c185098d))

### BREAKING CHANGES

- You need `cozy-ui >= 122.0.0`. AssistantDesktop
  componentsProps.SearchBarDesktop.elevation is now a number instead of
  a bool. Default value is the same.

# [0.2.0](https://github.com/cozy/cozy-libs/compare/cozy-search@0.1.0...cozy-search@0.2.0) (2025-03-27)

### Features

- **Search:** Change search icon depending on theme ([54e2e06](https://github.com/cozy/cozy-libs/commit/54e2e069889e4f889e8e70eccf86aa4b5e0dfdfd))
- **Search:** Upgrade cozy-ui ([1d6fcd0](https://github.com/cozy/cozy-libs/commit/1d6fcd06e25b993c3ab41a7e903941761f030b37))

### BREAKING CHANGES

- **Search:** You must have `cozy-ui >= 121.5.0`

# 0.1.0 (2025-03-14)

### Features

- Create a cozy-search package ([38fb9fa](https://github.com/cozy/cozy-libs/commit/38fb9fa92027769be11987ae4aa1309dfde72358))
